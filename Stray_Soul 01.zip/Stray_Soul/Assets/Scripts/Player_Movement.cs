﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Movement : MonoBehaviour
{
    //declears variables speed and rgb for rigidbody physics
    public float speed;
    private Rigidbody rgb;
    // Start is called before the first frame update
    void Start()
    {
        //Gets Rigidbody physics from Unity engine
        rgb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //assigns movement horizontally and vertically to floats
        float MoveHorizontal = Input.GetAxis("Horizontal");
        float MoveVertical = Input.GetAxis("Vertical");

        //Allows movement in each direction
        Vector3 movement = new Vector3(MoveHorizontal, 0.0f, MoveVertical);


        //Adds force so the player can start moving
        rgb.AddForce(movement * speed);
    }
}
