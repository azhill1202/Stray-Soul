﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pick_Up : MonoBehaviour
{
    public Transform player;

    public void OnTriggerEnter(Collider other)
    {
        if (Input.GetButton("E"))
        {
            Destroy(player);
        }
    }
    public void Setparent(GameObject newParent)
    {
        player.transform.parent = newParent.transform;

    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
